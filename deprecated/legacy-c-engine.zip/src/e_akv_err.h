/* Copyright (c) Microsoft Corporation.
   Licensed under the MIT License. */

#ifndef HEADER_AKVERR_H
#define HEADER_AKVERR_H

#define AKVerr(f, r) ERR_AKV_error((f), (r), __FILE__, __LINE__)

/* AKV function codes. */
#define AKV_F_CTRL 0x100
#define AKV_F_CTX_NEW 0x101
#define AKV_F_INIT 0x102
#define AKV_F_LOAD 0x103
#define AKV_F_RSA_PRIV_DEC 0x104
#define AKV_F_RSA_PRIV_ENC 0x105
#define AKV_F_GET_PRIVATE_RSA 0x106
#define AKV_F_GET_PRIVATE_EC_KEY 0x107
#define AKV_F_EC_KEY_SIGN 0x108
#define AKV_F_EC_KEY_SIGN_SETUP 0x109
#define AKV_F_EC_KEY_SIGN_SIG 0x10A
#define AKV_F_LOAD_PRIVKEY 0x10B
#define AKV_F_ACQUIRE_AKV 0x10C
#define AKV_F_RSA_SIGN 0x10D
#define AKV_F_LOAD_KEY_CERT 0x10E

/* AKV reason codes. */
#define AKV_R_ALLOC_FAILURE 0x100
#define AKV_R_CANT_FIND_AKV_CONTEXT 0x101
#define AKV_R_PARSE_KEY_ID_ERROR 0x102
#define AKV_R_LOAD_PUBKEY_ERROR 0x103
#define AKV_R_OPEN_ERROR 0x104
#define AKV_R_UNSUPPORTED_SSL_CLIENT_CERT 0x105
#define AKV_R_CANT_GET_KEY 0x106
#define AKV_R_CANT_GET_METHOD 0x107
#define AKV_R_ENGINE_NOT_INITIALIZED 0x108
#define AKV_R_FILE_OPEN_ERROR 0x109
#define AKV_R_INVALID_RSA 0x10A
#define AKV_R_INVALID_EC_KEY 0x10B
#define AKV_R_UNSUPPORTED_KEY_ALGORITHM 0x10C
#define AKV_R_UNKNOWN_COMMAND 0x10D
#define AKV_R_CANT_CREATE_X509 0x10E
#define AKV_R_INVALID_STORE_LOCATION 0x10F
#define AKV_R_CANT_OPEN_STORE 0x110
#define AKV_R_INVALID_KEY_SPEC 0x111
#define AKV_R_INVALID_CERT 0x112
#define AKV_R_CANT_FIND_CERT 0x113
#define AKV_R_INVALID_THUMBPRINT 0x114
#define AKV_R_INVALID_MD 0x115
#define AKV_R_NO_PADDING 0x116
#define AKV_R_CANT_GET_PADDING 0x117
#define AKV_R_CANT_GET_AKV_KEY 0x118
#define AKV_R_INVALID_SALT 0x119
#define AKV_R_INVALID_PADDING 0x11A
#define AKV_R_AKV_SIGN_HASH_FAIL 0x11B
#define AKV_R_AKV_DECRYPT_FAIL_1 0x11C
#define AKV_R_AKV_DECRYPT_FAIL_2 0x11D
#define AKV_R_ENCODE_FAIL 0x11E

int ERR_load_AKV_strings(void);
void ERR_unload_AKV_strings(void);
void ERR_AKV_error(int function, int reason, char *file, int line);

#endif
#pragma once
